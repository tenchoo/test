<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-18
 * Time: 19:27
 */

namespace app\domain;


use app\src\base\helper\ValidateHelper;
use app\src\favorites\logic\FavoritesLogic;
use app\src\favorites\model\Favorites;
use app\src\goods\action\ProductAddAction;
use app\src\goods\action\ProductDetailAction;
use app\src\goods\action\ProductSearchAction;
use app\src\goods\logic\ProductAttrLogic;
use app\src\goods\logic\ProductGroupLogic;
use app\src\goods\logic\ProductLogic;
use app\src\goods\model\Product;

use app\src\ewt\logic\BookunitLogicV2;
use app\src\ewt\logic\UserBookLogicV2;
use app\src\file\logic\AudioFileLogic;
/**
 * 商品相关接口
 * Class ProductDomain
 * @author hebidu <email:346551990@qq.com>
 * @package app\src\domain
 */
class ProductDomain extends BaseDomain
{

    /**
     * 商品添加接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function add(){
        $action = new ProductAddAction();
        $params = $this->getOriginData();
        $result = $action->add($params);
        $this->exitWhenError($result,true);
    }

    /**
     * 查询分组商品
     * 2017-08-03 15:38:21
     */
    public function group(){
        $this->checkVersion(100);
        $size  = max($this->_post('size',10),1);
        $page  = max($this->_post('page',1),1);
        $group = intval($this->_post('group',0));

        if($group === 16){ // 上架时间后先的商品列表
            $params = [
                'page_index'=>$page,
                'page_size' =>$size,
                'order'     =>'d',
                'lang'      =>$this->lang,
                'cate_id'   =>'',
                'prop_id'   =>'',
                'keyword'   =>'',
            ];
            $r  = (new ProductSearchAction)->search($params);
            if($r['status']){
                foreach ($r['info']['list'] as &$v) {
                    $v['p_id'] = $v['id'];
                    $v['g_id'] = 16;
                    unset($v['detail']);
                    unset($v['id']);
                    $v['min_price'] = $v['_min_price'];
                    $v['max_price'] = $v['_max_price'];
                } unset($v);
            }
        }else{
            //15; //热门
            //16; //推荐
            //6077; //限时抢购
            $l = new ProductGroupLogic;
            $r = $l->queryList(['g.g_id'=>$group,'p.onshelf'=>1,'p.status'=>1],['curpage'=>$page,'size'=>$size],'g.display_order desc',false,'g.g_id,g.p_id,g.end_time,p.name,secondary_headlines,cate_id,store_id,synopsis,img_id as main_img');
        }
        $this->exitWhenError($r,true);
    }

    /**
     * 商品详情接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function detail(){
        $this->checkVersion("100");
        $id  = $this->_post("id",'',lang('id_need'));
        $uid = $this->_post("uid",0);

        //book info
        $action = new ProductDetailAction();
        $r = $action->detail($id);
        $this->exitWhenError($r);

        $info = $r['info'];
        //add expire_time
        $info['expire_time'] = (new UserBookLogicV2())->getExpireTime($uid,$id);

        //+ view number
        $this->incViewCnt($id);

        //add units info
        $info['units'] = (new BookunitLogicV2())->getAllByBookId($id);

        //add zip file info
        $ids = (new BookunitLogicV2)->getAudioIdsByBookId($id);
        $r = (new AudioFileLogic)->zipFiles("book_".$id,$ids);
        $info['zip_md5']  = $r['status'] ? md5(implode(',', $ids)) : '';
        $info['zip_size'] = $r['status'] ? filesize($r['info']) : $r['info'];
        $this->apiReturnSuc($info);
    }

    /**
     * 增加查看次数
     * @param $id
     */
    private function incViewCnt($id){
        (new ProductAttrLogic())->setInc(['pid'=>$id],'view_cnt');
    }

    //我的书籍列表
    public function myBooks(){
        $this->checkVersion("100");
        $params = $this->parsePost('uid|0|int','cate_id|0|int,kword,page_index|1|int,page_size|10|int');
        extract($params);

        $map = ['b.uid'=>$uid];
        if($cate_id) $map['p.cate_id'] = $cate_id;
        if($kword) $map['p.name'] = ['like','%'.$kword.'%'];
        $field = 'b.expire_time,b.buy_time,img.img_id as img_main';
        $field .= ',p.name,p.uid as author,p.secondary_headlines,p.cate_id,p.onshelf,p.synopsis,p.id as p_id';
        $r = (new UserBookLogicV2)->getUserBooks($map,['curpage'=>$page_index,'size'=>$page_size],'b.update_time desc',false,$field);
        !$r['status'] && $this->apiReturnErr($r['info']);
        $info = $r['info'];

        //添加书籍zip文件信息
        foreach ($info['list'] as &$v) {
            $id = $v['p_id'];
            $ids = (new BookunitLogicV2)->getAudioIdsByBookId($id);
            $r = (new AudioFileLogic)->zipFiles("book_".$id,$ids);
            $v['zip_md5']  = $ids ? md5(implode(',', $ids)) : '';
            $v['zip_size'] = $r['status'] ? filesize($r['info']) : $r['info'];

        } unset($v);

        $this->apiReturnSuc($info);
    }

    /**
     * 商品搜索接口
     * 101: 增加了uid参数
     * @author rainbow <email:977746075@qq.com>
     */
    public function search(){
        $this->checkVersion("101","增加了uid参数");

        // $params = $this->getParams(['order','cate_id','prop_id','keyword','page_index','page_size']);
        $params = $this->parsePost('','order|d,cate_id|0|int,prop_id|0|int,keyword,page_index|1|int,page_size|10|int,l_price|0|int,r_price|0|int,uid|0|int');
        // $l_price = $this->_post('l_price',-1);
        // $r_price = $this->_post('r_price',-1);
        // if($l_price != -1 && $r_price != -1 && !empty($l_price) && !empty($r_price)){
        //     $params['l_price'] = $l_price;
        //     $params['r_price'] = $r_price;
        // }
        $params['lang'] = $this->lang;
        if($params['l_price']<1) unset($params['l_price']);
        if($params['r_price']<1) unset($params['r_price']);
        // if($params['cate_id']<1) unset($params['cate_id']);
        // if($params['prop_id']<1) unset($params['prop_id']);
        if($params['uid']<1) unset($params['uid']);
        $r  = (new ProductSearchAction)->search($params);
        $this->exitWhenError($r,true);
    }

    /**
     * 商品搜索关键词接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function searchKeywords(){
        $keyword = $this->_post("keyword","");

        $logic = new ProductLogic();
        $map = [
            'name'=>['like','%'.$keyword.'%'],
            'onshelf'=>Product::SHELF_ON,
            'status'=>1
        ];

        $result = $logic->queryWithCount($map,['curpage'=>1,'size'=>10], false, false, "id,name,secondary_headlines");

        $list = $result['info'];
        if(is_array($list) && isset($list['count'])){
            $list = $list['list'];
            $result['info'] = $list;

            if(count($list) == 0){
                $map = [
                    'secondary_headlines'=>['like','%'.$keyword.'%'],
                    'onshelf'=>Product::SHELF_ON,
                    'status'=>1
                ];

                $result = $logic->queryWithCount($map,['curpage'=>1,'size'=>10], false, false, "id,name,secondary_headlines");

                $list = $result['info'];
                if(is_array($list) && isset($list['count'])){
                    $list = $list['list'];
                    $result['info'] = $list;
                }
            }

        }

        $this->exitWhenError($result,true);
    }

}