<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2017-02-17
 * Time: 11:07
 */

namespace app\domain;

use app\src\i18n\helper\LangHelper;
use app\src\session\action\LoginSessionLogoutAction;
use app\src\session\action\LoginSessionQueryAction;
use app\src\session\logic\LoginSessionLogic;
use app\src\ewt\logic\UserDeviceLogicV2;
use app\src\ewt\logic\UserDeviceUnbindLogicV2;
use think\Db;

class LoginDeviceDomain extends BaseDomain
{
    /**
     *
     */
    public function query(){
        $uid = $this->_post('uid','',LangHelper::lackParameter("uid"));
        $result = (new LoginSessionQueryAction())->query($uid);
        $this->returnResult($result);
    }

    public function logout(){
        $uid = $this->_post('uid','',LangHelper::lackParameter("uid"));
        $s_id = $this->_post('s_id','',LangHelper::lackParameter("s_id"));
        $result =  (new LoginSessionLogoutAction())->logout($uid,$s_id);
        $this->returnResult($result);
    }

    //用户设备列表
    //101 rsp+ 下次解绑时间 : 2017-08-18 15:42:33
    public function bindList(){
        $this->checkVersion([100,101]);
        $uid = $this->_post('uid','',Llack("uid"));

        $list =(new UserDeviceLogicV2())->queryNoPaging(['uid'=>$uid]);

        $api_ver = intval($this->request_api_ver);
        if(100 == $api_ver){
            $this->apiReturnSuc($list);
        }else{
            $ret = [];
            $ret['list'] = $list;
            $ret['next_unbind_after_seconds'] = (new UserDeviceUnbindLogicV2)->lastUnbindTime($uid);
            $this->apiReturnSuc($ret);
        }
    }

    // 用户设备解绑
    // APP解绑 时 添加周期解绑限制 2017-08-18 14:35:39
    public function unbind(){
        $params = $this->parsePost('uid|0|int,s_id,device_token','');
        extract($params);
        $now = time();

        // 能否解绑APP设备
        $r = (new UserDeviceUnbindLogicV2)->canUnbind($uid);
        !$r['status'] && $this->apiReturnErr($r['info']);

        $r = (new UserDeviceLogicV2)->getInfo(['uid'=>$uid,'token'=>$device_token]);
        if($r){
            $info = $r;
            Db::startTrans();
            $add = [
                'uid'         =>$info['uid'],
                'token'       =>$info['token'],
                'type'        =>$info['type'],
                'version'     =>$info['version'],
                'model'       =>$info['model'],
                'create_time' =>$now,
            ];
            $id = (new UserDeviceUnbindLogicV2)->add($add);
            if(!$r){
                Db::rollback();
                $this->apiReturnErr('操作失败');
            }
            $r = (new UserDeviceLogicV2)->delete(['uid'=>$uid,'token'=>$device_token]);
            if(!$r){
                Db::rollback();
                $this->apiReturnErr('操作失败');
            }
            Db::commit();
            $this->apiReturnSuc('操作成功');
        }else{
            $this->apiReturnErr('用户未绑定此设备');
        }
    }
}