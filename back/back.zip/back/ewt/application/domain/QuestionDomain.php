<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-15
 * Time: 16:38
 */
namespace app\domain;

use app\src\base\enum\ErrorCode;
use app\src\base\helper\ConfigHelper;
use app\src\base\helper\ValidateHelper;
use app\src\i18n\helper\LangHelper;
use app\src\ewt\logic\BookunitLogicV2;
use app\src\ewt\logic\QuestionLogicV2;
use app\src\ewt\logic\UserBookLogicV2;
use app\src\ewt\logic\UserQuestionLogicV2;
use app\src\ewt\logic\SchoolReportLogicV2;
use app\src\ewt\logic\AnswerLogicV2;
use app\src\goods\logic\ProductLogic;
use app\src\ewt\logic\BookunitQuestionLogicV2;
use app\src\file\logic\AudioFileLogic;
use think\Db;

class QuestionDomain extends BaseDomain {

  //单元搜索 - 用户做过的书籍单元
  public function preSearch(){
    $this->checkVersion(100);
    $params = $this->parsePost('uid|0|int','kword,book_id|0|int,current_page|1|int,per_page|10|int');
    extract($params);

    $map = ['s.uid'=>$uid];//,'b.level'=>['in',[1,2]]
    if($book_id){ //查询某本书的
      $map['b.book_id'] = $book_id;
    }else{ //查询做过题的
      if($kword){
        $kword = strip_tags($kword);
        $map['p.name'] = ['like','%'.$kword.'%'];
      }
    }
    //查询答过题的书 + 1/2单元
    $r = (new SchoolReportLogicV2)->queryBookDone($map,['curpage'=>$current_page,'size'=>$per_page],false,[],'p.name as book_name,p.id as book_id');
    !$r['status'] && $this->apiReturnErr($r['info']);

    $this->apiReturnSuc($r['info']);
  }
  //单元答题 - 列表 - 成绩单/错题簿
  //todo : 试卷的答题列表
  public function doneList(){
    $this->checkVersion("100");
    $params = $this->parsePost('uid|0|int,answer_type|-1|int','book_id|0|mulint,unit_id|0|mulint,test_id|0|mulint,order|1|int,current_page|1|int,page_size|10|int');
    extract($params);

    //? answer_type
    !in_array($answer_type,[0,1]) && $this->apiReturnErr(Linvalid('answer_type'));
    //? order
    !in_array($order,[0,1]) && $this->apiReturnErr(Linvalid('order'));
    //? book_id/test_id/unit_id 三选一
    $map = ['s.uid'=>$uid];
    if($answer_type == 1) $map['s.error_cnt'] = ['>',0];
    // 排序
    $sort = 's.bookunit_id asc'; //单元id小大
    if($order ==1) $sort = 's.create_time desc'; //答题时间大小

    $null = ['list'=>[],'count'=>0];
    $is_test = false; //是否查询试卷
    if($book_id){     //查询书籍答题
      $book_ids = explode(',', $book_id);
      $map2 = ['level'=>3];
      if(count($book_ids)>1) $map2['book_id'] = ['in',$book_ids];
      else $map2['book_id'] = $book_id;
      //查询3级单元
      $r = (new BookunitLogicV2)->queryNoPaging($map2,false,'id');
      if($r){
        $ids = getArrColumn($r,'id');
        if($ids) $map['s.bookunit_id'] = ['in',$ids];
        else $this->apiReturnSuc($null);
      }else{
        $this->apiReturnSuc($null);
      }
    }elseif($unit_id){ //查询单元答题
      $unit_id = explode(',', $unit_id);
      //? 1级unit/2级unit 下的三级单元
      $r = (new BookunitLogicV2)->getLevel3Children($unit_id);
      if($r) $map['s.bookunit_id'] = ['in',$r];
      else $this->apiReturnSuc($null);

    }elseif($test_id){ //查询试卷做题
      $test_id = explode(',', $test_id);

      if(count($test_id)>1) $map['s.testpaper_id'] = ['in',$test_id];
      else $map['s.testpaper_id'] = $test_id;
      $is_test = true;
    }

    if($is_test){ //试卷做题
      //todo : 查询 试卷答题
      $this->apiReturnSuc('制作中,请期待...');
    }else{ //单元做题
      $r = (new SchoolReportLogicV2)->queryWithUnit($map,['curpage'=>$current_page,'size'=>$page_size],$sort,[],'s.id,s.create_time,s.update_time,s.correct_cnt,s.error_cnt,s.missing_cnt,s.bookunit_id as unit_id,s.use_time,b.unit_name,b.book_id,p.name as book_name');
      if(!$r['status']) $this->apiReturnErr($r['info']);
      $this->apiReturnSuc($r['info']);
    }

  }
  //单元答题 - 对错概览 + 题目快照
  //101 : 适应性修改 2017-07-27 11:28:29
  public function submitDetail(){
    $this->checkVersion("101");
    $params = $this->parsePost('uid|0|int,unit_id|0|int,id|0|int','');
    extract($params);

    //? unit_id 3级
    // $r = (new BookunitLogicV2)->getInfo(['id'=>$unit_id,'level'=>3]);
    //? 答过题
    $r = (new SchoolReportLogicV2)->getInfoWithUnit(['s.id'=>$id,'s.bookunit_id'=>$unit_id,'s.uid'=>$uid],false,'b.id as unit_id,s.correct_cnt,s.error_cnt,s.missing_cnt,s.use_time,s.create_time,b.unit_name,s.snap');
    !$r && $this->apiReturnErr('未发现做题记录');
    //q.status 注意题目状态
    $ret = $r->getData();

    //parent name
    $r = (new BookunitLogicV2)->getInfo(['id'=>$unit_id],false,'parent_unit,unit_name');
    !$r && $this->apiReturnErr(Linvalid('parent'));
    $parent = $r['parent_unit'];
    $r = (new BookunitLogicV2)->getField(['id'=>$parent],'unit_name');
    $ret['parent_unit_name'] = $r;
    $ret['parent_unit_id']   = $parent;

    //查询题目详情 + 题目状态
    // $r = (new UserQuestionLogicV2)->queryWithQuestion(['uq.uid'=>$uid,'uq.bookunit_id'=>$unit_id],'uq.id asc','uq.answer_type,q.id,q.title,q.parent_id');
    // !$r && $this->apiReturnErr('未发现做题信息');

    // $ret['work'] = $r;
    //题目详情
    $ret['list'] = json_decode($ret['snap'],true);
    unset($ret['snap']);
    $this->apiReturnSuc($ret);
  }

  //单元做题 - 删除
  public function submitUnitDel(){
    $this->checkVersion("100");
    $params = $this->parsePost('uid|0|int,id|0|int','');
    extract($params);

    Db::startTrans();
    $r = (new SchoolReportLogicV2)->delete(['id'=>$id,'uid'=>$uid]);
    if($r){
      if((new UserQuestionLogicV2)->delete(['report_id'=>$id,'uid'=>$uid])){
        Db::commit();
        $this->apiReturnSuc('删除成功');
      }else{
        Db::rollback();
        $this->apiReturnErr('删除失败');
      }
    }else{
      Db::rollback();
      $this->apiReturnErr('删除失败');
    }
  }

  // 单元做题 - 不要答案
  // 题目可无序 2017-08-12 16:32:14
  public function submitNoAnswer(){
    $this->checkVersion("100");
    $params = $this->parsePost('uid|0|int,unit_id|0|int,use_time|0|int,answer_multi','');
    extract($params);

    $now = time();
    $arr = explode(',', $answer_multi);
    $answer_arr = [];
    foreach ($arr as $v) {
      $r = explode(':', $v);
      count($r)==2 && $answer_arr[] = ['id'=>$r[0],'an'=>$r[1]];
    }
    //? 统计
    $l = (new QuestionLogicV2);
    $lost =0;$right =0;$error =0;
    foreach ($answer_arr as &$v) {
      $id = intval($v['id']);
      $an = intval($v['an']); //0=>F,1=>T,other=>Lost
      if(!in_array($an,[0,1,2])) $this->apiReturnErr("题目".$id."未知答案");
      if($an==1){      $error ++;
      }elseif($an==0){ $right ++;
      }elseif($an==2){ $lost ++;
      }
      // 查询题目情况
      $r = $l->getInfo(['id'=>$id,'status'=>1]);
      !$r && $this->$this->apiReturnErr("未知题目".$id);
      $parent = (int) $r['parent_id'];
      $v['parent'] = $parent;
      if($parent){
        $v['count'] = $l->count(['parent_id'=>$parent,'status'=>1]);
      }else{ // 小题
        $v['count'] = 1;
      }
    } unset($v);
    // dump($answer_arr); // id an parent count的数组
    // 把大题题号放外面
    $outer_ids = []; // id child(大题)/an(小题) 的数组
    $len = count($answer_arr);
    for ($i=0; $i < $len; ) {
      $v = $answer_arr[$i];
      $ids = array_slice($answer_arr,$i,$v['count']); // 每个题目
      $i += $v['count'];
      if($v['parent']){
        $vvv = ['id'=>$v['parent'],'child'=>[]];
        foreach ($ids as $vv) {
          $vvv['child'][$vv['id']] = $vv['an'];
        }
        $outer_ids[] = $vvv;
      }else{ // 小题
        $outer_ids[] = ['id'=>$ids[0]['id'],'an'=>$ids[0]['an']];
      }
    }
    // halt($outer_ids);
    // [3] => array(2) { //大题
    //   ["id"] => int(55)
    //   ["child"] => array(3) {
    //     [56] => string(1) "0"
    //     [57] => string(1) "1"
    //     [58] => string(1) "2"
    //   }
    // }
    // [4] => array(2) { //小题
    //   ["id"] => string(1) "1"
    //   ["an"] => string(1) "1"
    // }
    // 小题 ids
    $question_ids   = getArrColumn($answer_arr,'id');
    // $question_atype = getArrColumn($answer_arr,'an');
    // 各种检查 返回现在第几次答题
    $t = $this->submitPreCheck($unit_id,$uid,$question_ids,$use_time) + 1;
    // 现在的 question list
    $r = (new BookunitQuestionLogicV2)->queryWithAllQuestion(['bq.unit_id'=>$unit_id]);
    if(!$r['status']) $this->apiReturnErr($r['info']);
    $info = $r['info'];
    // 不重复的题目 key为大题id
    $info = changeArrayKey($info);
    // 根据题号 查找一级题目ids
    $save_info = [];
    foreach ($outer_ids as $v) {
      $id = $v['id'];
      $q_info = $info[$id];
      if($q_info['child']){ // 含有小题
        foreach ($q_info['child'] as &$vv) {
          $vv['answer_type'] =  $v['child'][$vv['id']];
        } unset($vv);
      }else{
        $q_info['answer_type'] = $v['an'];
      }
      $save_info[] = $q_info;
    }
    $snap = json_encode($save_info);

    Db::startTrans();
    //保存答题统计 school_report
    $map = [
      'create_time'  =>$now,
      'update_time'  =>$now,
      'snap'         =>$snap, //问题快照
      'uid'          =>$uid,
      'testpaper_id' =>0,
      'bookunit_id'  =>$unit_id,
      'correct_cnt'  =>$right,
      'error_cnt'    =>$error,
      'missing_cnt'  =>$lost,
      'use_time'     =>$use_time
    ];
    $report = (new SchoolReportLogicV2)->add($map);
    if(!$report){
      Db::rollback();
      $this->apiReturnErr('提交失败1');
    }
    $en =[];
    foreach ($answer_arr as $v) {
      $en[] = [
        'report_id'    =>$report,
        'uid'          =>$uid,
        'question_id'  =>$v['id'],
        'user_answer'  =>'',
        'answer_type'  =>$v['an'],
        'create_time'  =>$now,
        'update_time'  =>$now,
        'testpaper_id' =>0,
        'bookunit_id'  =>$unit_id
      ];
    }
    //保存详情答题
    if($en && !(new UserQuestionLogicV2)->addAll($en)){
      Db::rollback();
      $this->apiReturnErr('提交失败2');
    }
    Db::commit();
    $this->apiReturnSuc('提交答案成功,当前第'.$t.'次提交');
  }

  //单元做题 - 提交答案
  //todo : fix
  public function submitAnswer(){
    $this->checkVersion("100");
    $params = $this->parsePost('uid|0|int,unit_id|0|int,use_time|0|int,answer_json','');
    extract($params);

    $now = time();
    $answer_arr = json_decode($answer_json,true); //答案
    empty($answer_arr) && $this->apiReturnErr('答题格式错误');
    // check
    $this->submitPreCheck($unit_id,$uid,array_keys($answer_arr),$use_time);
    //? 统计
    Db::startTrans();
    $all =0;$right =0;$error =0;$en =[];
    foreach ($answer_arr as $k=>$v) { //每题的答案
      $all++;$is_correct = 0;
      $q_id = intval($k);
      if(!is_array($v)){
        Db::rollback();
        $this->apiReturnErr('答案格式错误');
      }
      //题目内容
      $r = (new BookunitQuestionLogicV2)->getInfoWithQuestion(['question_id'=>$q_id]);
      if(empty($r)){
        Db::rollback();
        $this->apiReturnErr('题目id错误');
      }
      $qustion_snap = json_encode($r);
      //查询正确答案
      $r = (new AnswerLogicV2)->queryNoPaging(['q_id'=>$q_id,'is_real'=>1],'real_sort desc','title');
      $real_arr = getArrColumn($r,'title');
      // dump($real_arr);
      if($real_arr){ //错或对
        if($v){
          if(json_encode($real_arr) == json_encode($v)){
            $right ++;$is_correct = 1;
          }else{
            $error ++;
          }
        }
      }else{ //无需答题 - 算对
        $right ++;$is_correct = 1;
      }
      //保存答题信息 user_question
      $en[] = [
        'question_id'  =>$q_id,
        'user_answer'  =>json_encode($v),
        'is_correct'   =>$is_correct,
        'create_time'  =>$now,
        'update_time'  =>$now,
        'testpaper_id' =>0,
        'bookunit_id'  =>$unit_id,
        'use_time'     =>$use_time,
      ];
    }
    if(!(new UserQuestionLogicV2)->addAll($en)){
      Db::rollback();
      $this->apiReturnErr('提交失败1');
    }
    //保存答题统计 school_report
    $map = [
      'create_time'  =>$now,
      'update_time'  =>$now,
      'snap'         =>$question_snap, //问题快照
      'uid'          =>$uid,
      'testpaper_id' =>0,
      'bookunit_id'  =>$unit_id,
      'correct_cnt'  =>$right,
      'error_cnt'    =>$error,
      'missing_cnt'  =>max($all-$right-$error,0)
    ];
    if(!(new SchoolReportLogicV2)->add($map)){
      Db::rollback();
      $this->apiReturnErr('提交失败2');
    }
    dump($question_snap);
    // Db::commit();
    $this->apiReturnSuc('提交答案成功');
  }

  //单元详情 - hook : s_id
  // rsp 可以随机返回 2017-08-11 11:44:53
  // rsp fix : 随机返回时重设题号 2017-08-12 15:41:47
  // rsp + : 单元处+audio_id 2017-08-12 15:41:47
  public function unitDetail(){
    $this->checkVersion("101");
    $params = $this->parsePost('uid|0|int,unit_id|0|int','');
    extract($params);

    // $str = "Tom :{{td}} Hi! I'm Tom. {{tr}}\nAlice :{{td}}{{co}}{{co}} ,{{br}}Nice to meet you,Tom.{{tr}}\nTom :{{td}} {{co}} ,Alice.";
    // $l = new QuestionLogicV2;
    // $r = $l->parseContent($str,6202);
    // dump($r);die();

    //? unit
    $l = new BookunitLogicV2;
    $r = $l->getInfo(['id'=>$unit_id,'level'=>3]);
    !$r && $this->apiReturnErr(Linvalid('unit_id'));

    // 返回方式
    $is_rand  = (int) $r['is_rand'];
    $audio_id = (int) $r['audio_id'];
    $r2 = (new AudioFileLogic)->getInfo(['id'=>$audio_id]);
    !$r2['status'] && $this->apiReturnErr($r2['info']);
    $audio_info = $audio_id ?  $r2['info']: [];
    //? 作者
    $book_id  = (int) $r['book_id'];
    $r2 = (new ProductLogic)->getInfo(['id'=>$book_id]);
    !$r2['status'] &&  $this->apiReturnErr($r2['info']);
    $book_author = intval($r2['info']['uid']);
    $is_author = ($uid == $book_author) ? 1:0;
    if(!$is_author){ //用户
      //? 收费
      $is_free = (int) $r['is_free'];
      if(!$is_free){ //收费
        //? 买了吗
        $r2 = (new UserBookLogicV2)->getInfo(['book_id'=>$book_id,'uid'=>$uid]);
        !$r2 && $this->apiReturnErr('您并未购买本书');
        //? 过期
        intval($r2['expire_time'])<=time() && $this->apiReturnErr('本书已过期,请重新购买');
      }
    }

    $ret = [];
    $parent = (int) $r['parent_unit'];
    $ret = [
      'name'       =>$r['unit_name'],
      'id'         =>$r['id'],
      'parent'     =>$parent,
      'is_free'    =>$r['is_free'],
      'has_answer' =>$r['has_answer'],
      'is_author'  =>$is_author,
      'time_limit' =>$r['time_limit'],
      'is_rand'    =>$is_rand,
      'is_tip'     =>$r['is_tip'],
      'audio_id'   =>$audio_id,
      'audio_path' =>$audio_info ? config('site_url').$audio_info['path']:'',
      'audio_duration'=>$audio_info ? $audio_info['duration'] : 0
    ];
    //parent name
    $r = $l->getInfo(['id'=>$parent],false,'parent_unit,unit_name');
    !$r && $this->apiReturnErr(Linvalid('parent'));
    $parent = $r['parent_unit'];
    $ret['parent_name'] = $r['unit_name'];
    $ret['top'] = $parent;
    //top name
    $ret['top_name'] = $l->getField(['id'=>$parent],'unit_name');
    //question list
    $r = (new BookunitQuestionLogicV2)->queryWithAllQuestion(['bq.unit_id'=>$unit_id]);
    if(!$r['status']) $this->apiReturnErr($r['info']);
    $info = $r['info'];
    if($is_rand){ // 打乱题目 并重新设置题号
      shuffle($info);
      $i = 0;
      foreach ($info as &$v) {
        $i++;
        $v['title'] = $i;
      } unset($v);
    }
    $ret['list'] = $info;
    $this->apiReturnSuc($ret);
  }

  //test 根据题目id获取题目内容
  public function test(){
    $this->checkVersion("102",'查询type增加,返回内容控制位变更');
    // $id = $this->_post('id','',Llack('id'));
    $dt_type = intval($this->_post('dt_type',0)); //查询所有题型 或 具体题型

    // $info = [];
    // if($dt_type<1 || $dt_type>8){
    //   $dt_type = mt_rand(1,8);
    // }
    $r = $this->getQuestion($dt_type);
    $this->exitWhenError($r,true);
  }

// ------------------------ private ------------------------
  // 提交答案前的部分检查
  // 单元 用户 期限 (做过) 顺序
  // 20170506 去掉做题检查 返回第几次做题
  // 去掉提交顺序检查 2017-08-12 15:49:27
  private function submitPreCheck($unit_id,$uid,$question_ids,$use_time){
    //? unit_id ? level=3
    $r = (new BookunitLogicV2)->getInfo(['id'=>$unit_id,'level'=>3]);
    empty($r) && $this->apiReturnErr('单元id错误');
    //? 付费章节
    $is_free = intval($r['is_free']);
    $book_id = intval($r['book_id']);
    $has_answer = intval($r['has_answer']);
    $time_limit = intval($r['time_limit']);//分钟
    //权限检查
    if(!$is_free){
      //? 用户买了
      $r = (new UserBookLogicV2)->getInfo(['book_id'=>$book_id,'uid'=>$uid]);
      !$r && $this->apiReturnErr('您并未购买本书');
      //? 过期
      intval($r['expire_time'])<=time() && $this->apiReturnErr('本书已过期,请重新购买');
    }
    //? 需要做题
    $has_answer!=1 && $this->apiReturnErr('无需答题');
    //? 超时
    ($time_limit && $time_limit*60 < $use_time) && $this->apiReturnErr('超时了');
    //? 有哪些发布的题
    $l = (new BookunitQuestionLogicV2);
    $r = $l->queryNoPagingWithQuestion(['bq.unit_id'=>$unit_id,'q.status'=>1],'bq.sort desc','bq.question_id,q.dt_type');
    empty($r) && $this->apiReturnErr('此单元下未查询到题目');
    // $q_ids = getArrColumn($r,'question_id');
    $q_ids = []; // 不重复的内层ids
    foreach ($r as $v) {
      $q_id   = (int) $v['question_id'];
      $q_type = (int) $v['dt_type'];
      //? 完型填空
      if($q_type == 6227){
        //小题ids
        $r2 = (new QuestionLogicV2)->queryNoPaging(['parent_id'=>$q_id,'status'=>1],'sort desc','id');
        foreach ($r2 as $v) {
          $q_ids[] = $v['id'];
        }
        // $r2 = getArrColumn($r2,'id');
        // $q_ids = array_merge($q_ids,$r2);
      }else{
        $q_ids[] = $q_id;
      }
    }
    // dump($q_ids);dump($question_ids);die();
    // (json_encode($q_ids) != json_encode($question_ids)) && $this->apiReturnErr('请按照题目顺序上传答案');
    if(count($q_ids) != count($question_ids)) $this->apiReturnErr('1.单元或已更新,请重新打开单元');
    foreach ($q_ids as $v) {
      !in_array($v,$question_ids) && $this->apiReturnErr('2.单元或已更新,请重新打开单元');
    }
    //? 提交过
    // $r = (new SchoolReportLogicV2)->getInfo(['uid'=>$uid,'bookunit_id'=>$unit_id]);
    // $r && $this->apiReturnErr('您已做完了此单元');
    //? 第几次做题
    return (new SchoolReportLogicV2)->count(['uid'=>$uid,'bookunit_id'=>$unit_id]);
  }
  //faker question data
  private function getQuestion($type=0){
    $type = intval($type);
    $info = [
      'title'          =>'A1',
      'content'        =>[], //题面
      'question'       =>'', //题问
      'dt_type'        =>$type,
      'audio_id'       =>0, //附加音频,int,0为无
      'origin_article' =>'原文题目解析',
      'knowlege'       =>'考察知识点',
      'come_form'      =>'题目来源',
      'answer'         =>[],
      'answer_true'    =>[],
      'answer_number'  =>0, //正确答案个数
      'child'          =>[],
    ];
    if($type == 6202){ //单项选择
      $info['answer_number'] = 3;
      $info['answer'] = [ //? 混淆  //? 排序
        ["Hi!","str",""],["Nice to meet you","str",""],["I'm Alice","str",""]
      ];
      $info['answer_true'] = [
        "Nice to meet you","I'm Alice","Hi!"
      ];
      $info['content'] = [
        [
          ["con",""],["con",""],["con",""]]
      ];
    }elseif($type == 6232){ //对话选择
      $info['answer_number'] = 3;
      $info['answer'] = [ //? 混淆  //? 排序
        ["Hi!","str",""],["Nice to meet you","str",""],["I'm Alice","str",""]
      ];
      $info['answer_true'] = [
        "Nice to meet you","I'm Alice","Hi!"
      ];
      $info['content'] = [
        [ //每个对话人
          ["str","Tom"],["str","Hi ! I'm Tom"]],
        [
          ["str","Alice"],["con",""],["con",""],["con","nl"],["str","Nice to meet you ,Tom"]],
        [
          ["str","Tom"],["con",""],["str","Alice."]],
      ];
    }elseif($type ==6203){ //图片选择
      $info['answer_number'] =1;
      $info['answer'] = [
        ["A","img",1],["B","img",2],["C","img",3],["D","img",4]
      ];
      $info['answer_true'] = ["A"];
    }elseif($type ==6226){ //单项选择
      $info['answer_number'] =1;
      $info['question'] = 'Tom is a Chinese boy.';
      $info['answer'] = [
        ["A","str","I'm find, thanks"],
        ["B","str","it's blue"],
        ["C","str","Hello!"],
      ];
      $info['answer_true'] = ["A"];
      $info['content'] = [
        [ //每段
          ['str','Tom is a boy. He comes from England.He is 11 olda boy. He comes from England.'],
        ],
      ];
    }elseif($type ==6227){ //完型填空
      $info['title'] = "(一)英语网小编为考生们整理了高中英语完形填空专项训练，报考详细的名师讲解和答案，希望同学们学习、参考，英语水平能有所提高。";
      $info['answer_number'] =0;
      $info['content'] = [
        [ //每段
          ['str',"Tom is a "],['con',""],['str'," girl, SHe "],['con',""],
          ['str','11 years old. Mother is a '],['con',""],['str','Her father is 40 years old. he is very graceful and '],['con',""],
          ['str','Her father is 40 years old. he is very graceful and '],
          ['con',""],
        ]
      ];
      $arr = [
        'title'          =>'A1',
        'question'       =>'', //题问
        'dt_type'        =>3,  //选择
        'audio_id'       =>0, //附加音频,int,0为无
        'origin_article' =>'原文题目解析',
        'knowlege'       =>'考察知识点',
        'come_form'      =>'题目来源',
        'answer'         =>[
          ["A",'str',"I'm find, thanks"],["B",'str',"it's blue"],["C",'str','Hello!']
        ],
        'answer_true'    =>["A"],
        'answer_number'  =>1,
        'child'          =>[],
        'content'        =>[],
      ];
      $arr1 = $arr;$arr1['title'] = 'A2';
      $arr2 = $arr;$arr2['title'] = 'A3';
      $arr3 = $arr;$arr3['title'] = 'A4';
      $arr4 = $arr;$arr4['title'] = 'A5';
      $info['child'] = [
        $arr,$arr1,$arr2,$arr3,$arr4
      ];
    }elseif($type ==6228){ //看图选择T/F
      $info['answer_number'] =1;
      $info['answer'] = [['T','bool','1'],['F','bool','0']];
      $info['answer_true'] = ['T'];
      $info['content'] = [
        [ //每段
          ["img","1"]
        ]
      ];
    }elseif($type ==6229){ //单词听写 - 不显示答案
      $info['answer_number'] =1;
      $info['answer'] = [['what','str',''],['is','str',''],['this','str','']];
      $info['answer_true'] = ['what','is','this'];
      $info['content'] = [
        [ //每段
          ['con',''],['con',''],['con',''],['con','']]
      ];
    }elseif($type ==6233){ //单词拼写 - 不显示答案
      $info['answer_number'] =1;
      $info['answer'] = [['h','str',''],['a','str',''],['t','str',''],['w','str','']];
      $info['answer_true'] = ['w','h','a','t'];
      $info['content'] = [
        [ //每段
          ['con',''],['con',''],['con',''],['con','']]
      ];
    }elseif($type ==6230){ //判断选择T/F
      $info['answer_number'] =1;
      $info['question'] = "Tom is a Chinese boy";
      $info['answer'] = [['T','bool','1'],['F','bool','0']];
      $info['answer_true'] = ["T"];
      $info['content'] = [
        [ //每段
          ['str',"Tom is a Chinese boy,Tom is a Chinese boy"],
        ]
      ];
    }elseif($type ==6231){ //表格选择
      $info['answer_number'] = 6;
      $info['answer'] = [['Mary',"str",""],['13',"str",""],['11',"str",""],['Three','str',""],['Two',"str",""],['Alice',"str",""],['Two',"str",""]];
      $info['answer_true'] = ['Mary','13','11','Three','Two','Two'];
      $info['content'] = [
        [ //每表格行
          ["str","名字"],["str","年龄"],["str","班级"]],
        [
          ["str","Tom"],["str","12"],["con",""],],
        [
          ["str","Mary"],["con",""],["con",""]],
        [
          ["con",""],["con",""],["con",""]],
      ];
    }else{
      return returnErr('题型错误');
    }
    return returnSuc($info);
  }
}