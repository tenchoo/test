<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-11-03
 * Time: 17:24
 */

namespace app\domain;
use app\src\banners\logic\BannersLogic;
use app\src\post\logic\PostLogic;
use app\src\goods\logic\ProductLogic;
use app\src\goods\logic\ProductGroupLogic;
// use app\src\banners\model\Banners;
// use app\src\base\helper\PageHelper;
// use app\src\base\helper\ValidateHelper;
// use app\src\index\action\IndexAction;

/**
 * app首页
 * Class IndexDomain
 * @author hebidu <email:346551990@qq.com>
 * @package app\src\domain
 */
class IndexDomain extends BaseDomain
{
    //首页
    public function index(){
        $this->checkVersion(101);
        $size = max($this->_post('size',10),1);

        $ret = [];
        //banner _ index 前3条
        $l = new BannersLogic;
        $r = $l->queryWithPosition(['position'=>BannersLogic::INDEX],['curpage'=>1,'size'=>3],'sort desc',false,'banner.img,banner.id,banner.sort,banner.title,banner.notes,banner.url,banner.url_type');
        $this->exitWhenError($r);
        $ret['banner'] = $r['info']['list'];
        //系统通知 _ index 前3条
        $l = new PostLogic;
        $map = ['post_category'=>PostLogic::SYSTEM_NOTICE,'post_status'=>'publish','start_time'=>['<',time()],'end_time'=>['>',time()]];
        $r = $l->query($map,['curpage'=>1,'size'=>3],'id desc',false,'id,post_title,main_img,post_excerpt,comment_count');
        $this->exitWhenError($r);
        $ret['notice'] = $r['info']['list'];

        // //微测试 - 推荐的分组商品
        // $l = new ProductGroupLogic;
        // $r = $l->queryList(['g.g_id'=>ProductGroupLogic::RECOMMEND,'p.onshelf'=>1,'p.status'=>1],['curpage'=>1,'size'=>$size],'g.display_order desc',false,'g.g_id,g.p_id,g.end_time,p.name,secondary_headlines,cate_id,store_id,synopsis,img_id as main_img');
        // 商品列表 添加后先
        $l = new ProductLogic;
        $r = $l->queryOnShelf([],['curpage'=>1,'size'=>$size],'create_time desc',false,'id,id as p_id,name,secondary_headlines,cate_id,store_id,synopsis');
        $this->exitWhenError($r);
        $list = $l->mergeImages($r['info']['list']);
        $list = $l->mergePrice($r['info']['list']);
        foreach ($list as &$v) {
            if(isset($v['_min_price'])){
                $v['min_price'] = $v['_min_price'];
                unset($v['_min_price']);
            }
            if(isset($v['_max_price'])){
                $v['max_price'] = $v['_max_price'];
                unset($v['_max_price']);
            }
        } unset($v);

        $ret['book'] = $list;
        $this->apiReturnSuc($ret);
    }
    /**
     * 首页商品接口
     * 101: 增加了收藏字段is_fav 有的时候为收藏id，没有为0 或 空字符串
     * 102: 商品数据也为数组
     * @author hebidu <email:346551990@qq.com>
     */
    // public function index(){
    //     $this->checkVersion(["102"],"商品数据也为数组");
    //     //返回数据
    //     $uid = $this->_post('uid','');
    //     $action = new IndexAction();
    //     //1. 过滤不喜欢的类目
    //     $result = $action->index($uid,$this->lang,new PageHelper($this->getPageParams()));
    //     $ads = $this->queryAd();
    //     if(ValidateHelper::legalArrayResult($result)){
    //         $data = $this->combine($result['info'],$ads);
    //         $result['info'] = $data;
    //     }
    //     $this->exitWhenError($result,true);
    // }

    // private function combine($info,$ads){
    //     $count = $info['count'];
    //     $list  = $info['list'];
    //     $total = count($ads) + count($list);
    //     $tmp   = [];
    //     $i     = 0;//ads index
    //     $j     = 0;//list index

    //     while($i + $j < $total){
    //         if(rand(0,10) < 5){
    //             if($j < count($list)){
    //                 array_push($tmp, ['type' => 'p', 'info' => [$list[$j]]]);
    //                 $j++;
    //             }elseif($i < count($ads)) {
    //                 array_push($tmp, ['type' => 'ad', 'info' => $ads[$i]]);
    //                 $i++;
    //             }
    //         }else{
    //             if($i < count($ads)) {
    //                 array_push($tmp, ['type' => 'ad', 'info' =>  $ads[$i]]);
    //                 $i++;
    //             }elseif($j < count($list)){
    //                 array_push($tmp, ['type' => 'p', 'info' => [$list[$j]]]);
    //                 $j++;
    //             }
    //         }
    //     }

    //     return ['count'=>$count,'list'=>$tmp];
    // }

    // /**
    //  * 向返回数据插入 广告条目
    //  * @author hebidu <email:346551990@qq.com>
    //  */
    // private function queryAd(){
    //     //1. 随机获取首页广告 进行插入
    //     $logic = new BannersLogic();
    //     $rand = rand(0,2);
    //     $result = $logic->query(['position'=>Banners::APP_AD],['curpage'=>1,'size'=>$rand]);
    //     if(!empty($result['info']) && isset($result['info']['list'])){
    //         //TODO: 支持多图片返回
    //         $list = $result['info']['list'];
    //         $tmp = [];
    //         foreach ($list as $item){
    //             array_push($tmp,[$item]);
    //         }
    //         return $tmp;
    //     }
    //     return [];
    // }
}