<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2017-02-22
 * Time: 11:28
 */

namespace app\domain;

use app\src\ewt\action\SurveyAction;

class SuggestDomain extends BaseDomain{

    public function add(){
        $params = $this->getParams(['text','email','tel','name','uid']);
    }

    //调查问卷 - 查询
    public function survey(){
      $this->checkVersion(100);
      $r = (new SurveyAction())->queryList();
      $this->apiReturnSuc($r);
    }

    //调查问卷 - 提交
    public function surveySubmit(){
      $this->checkVersion(100);

      $map = $this->parsePost('answer','');
      $answer = json_decode($map['answer'],true);

      $r = (new SurveyAction())->add($answer);
      $this->exitWhenError($r,true);
    }
}