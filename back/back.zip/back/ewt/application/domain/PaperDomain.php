<?php
namespace app\domain;

use app\src\file\logic\AudioFileLogic;
use app\src\ewt\logic\TestpaperLogicV2;
use app\src\ewt\logic\TestpaperQuestionLogicV2;

/**
 * 试卷相关接口
 * rainbow
 */
class PaperDomain extends BaseDomain{

  //试卷列表 - 暂
  public function query(){
    $this->checkVersion("100");
    $params = $this->parsePost('','uid|0|int,cate_id|0|int,page_index|1|int,page_size|10|int');
    extract($params);

    $map = [];
    $r = (new TestpaperLogicV2)->query($map,['curpage'=>$page_index,'size'=>$page_size],'create_time desc');
    foreach ($r['list'] as $v) {
      $id = $v['id'];
      // + zip_info
      $ids = (new TestpaperQuestionLogicV2)->getAudioIdsByPaperId($id);
      $r2 = (new AudioFileLogic)->zipFiles("paper_".$id,$ids);
      $v['zip_md5']  = $ids ? md5(implode(',', $ids)) : '';
      $v['zip_size'] = $r2['status'] ? filesize($r2['info']) : $r2['info'];
    }
    $this->apiReturnSuc($r);
  }

  //试卷详情 - 暂
  public function detail(){
    $this->checkVersion("100");
    $params = $this->parsePost('id|0|int','uid|0|int');
    extract($params);

    $map = ['id'=>$id];
    $paper = (new TestpaperLogicV2)->getInfo($map);
    if($paper){
      //todo : 查询题目信息
      $paper['list'] = [];
      // + zip_info
      $ids = (new TestpaperQuestionLogicV2)->getAudioIdsByPaperId($id);
      $r = (new AudioFileLogic)->zipFiles("paper_".$id,$ids);
      $paper['zip_md5']  = $ids ? md5(implode(',', $ids)) : '';
      $paper['zip_size'] = $r['status'] ? filesize($r['info']) : $r['info'];
    }
    $this->apiReturnSuc($paper);
  }

}