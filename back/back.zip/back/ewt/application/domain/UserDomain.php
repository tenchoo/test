<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-15
 * Time: 16:38
 */

namespace app\domain;


use app\src\base\enum\ErrorCode;
use app\src\base\helper\ConfigHelper;
use app\src\base\helper\ValidateHelper;
use app\src\i18n\helper\LangHelper;
use app\src\securitycode\logic\SecurityCodeLogic;
use app\src\securitycode\model\SecurityCode;
use app\src\tool\helper\GeoHashHelper;
use app\src\user\action\DeleteAction;
use app\src\user\action\LoginAction;
use app\src\user\action\RegisterAction;
use app\src\user\action\UpdateAction;
use app\src\user\enum\RegFromEnum;
use app\src\user\enum\RoleEnum;
use app\src\user\facade\DefaultUserFacade;
use app\src\user\logic\MemberLogic;
use app\src\user\logic\UcenterMemberLogic;
use app\src\user\model\UcenterMember;
use app\src\file\logic\UserPictureLogic;
use app\src\system\logic\DatatreeLogicV2;
use app\src\ewt\logic\SchoolLogicV2;
// use app\src\repairerApply\logic\RepairerApplyLogicV2;
/**
 * 用户个人资料相关
 * Class UserDomain
 * @author hebidu <email:346551990@qq.com>
 * @package app\domain
 */
class UserDomain extends BaseDomain
{

    /**
     * 自动登录接口 - 目前主要用于刷新
     * @author hebidu <email:346551990@qq.com>
     */
    public function autoLogin(){

        $uid = $this->_post('uid','',lang('id_need'));
        $auto_login_code = $this->_post('auto_login_code','',lang('auto_login_code_need'));

        $result = (new DefaultUserFacade())->autoLogin($uid,$auto_login_code,"",ConfigHelper::getValue('login_session_expire_time'));
        if(!$result['status']){
            $this->apiReturnErr($result['info'],ErrorCode::Api_Need_Login);
        }
        $this->exitWhenError($result,true);
    }

    /**
     * 更新用户信息接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function update(){
        $this->checkVersion("100");
        $params = $this->parsePost('uid|0|int','nickname,sex|0|int,loc_school,loc_area,loc_country|1|int,head|0|int,grade_code,sign');
        extract($params);

        // $uid = $this->_post('uid','',lang('lack_parameter',['param'=>'uid']));
        // $nickname = $this->_post('nickname','');
        // $sex   = $this->_post('sex','');
        // $sign  = $this->_post('sign','');//个性签名
        // $email = $this->_post('email','');//邮箱
        // $head   = $this->_post('head','');//头像
        // $realname    = $this->_post('realname','');
        // $idnumber    = $this->_post('idnumber','');

        // $loc_country = $this->_post('loc_country','');
        // $loc_area    = $this->_post('loc_area','');
        // $weixin    = $this->_post('weixin','');
        // $job_title = $this->_post('job_title','');//职位
        // $company   = $this->_post('company','');//公司

        // member_config 表字段更新
        $member_config = [];
        // !empty($job_title) && $member_config['job_title'] = $job_title;
        // !empty($company) && $member_config['company'] = $company;
        // !empty($weixin) && $member_config['weixin'] = $weixin;
        !empty($loc_country) && $member_config['loc_country'] = $loc_country;
        //? check area
        !empty($loc_area) && $member_config['loc_area'] = $loc_area;
        //? check school
        !empty($loc_school) && $member_config['loc_school'] = $loc_school;
        //? check grade
        !empty($grade_code) && $member_config['grade_code'] = $grade_code;

        // common_member 表字段更新
        $user_entity = [];
        // !empty($idnumber) && $user_entity['idnumber'] = $idnumber;
        // !empty($realname) && $user_entity['realname'] = $realname;
        !empty($head) && $user_entity['head'] = $head;
        !empty($nickname) && $user_entity['nickname'] = $nickname;
        in_array($sex,[0,1]) && $user_entity['sex'] = $sex;
        !empty($sign) && $user_entity['sign'] = $sign;

        // ucenter_member 表字段更新
        $ucenter_entity = [];
        // if(!empty($email)){
        //     $ucenter_entity['email'] = $email;
        // }

        $action = new UpdateAction();
        $entity = [
            'ucenter_entity' =>$ucenter_entity,
            'user_entity'    =>$user_entity,
            'member_config'  =>$member_config,
            'uid'            =>$uid
        ];
        $r = $action->update($entity);

        $this->exitWhenError($r,true);
    }

    /**
     * 找回密码-通过旧密码的形式
     * @author hebidu <email:346551990@qq.com>
     */
    public function updatePwdByOldPwd(){

        $this->checkVersion("100");

        $uid = $this->_post('uid','', lang('uid_need'));
        $password = $this->_post('password','', lang('password_need'));
        $new_password = $this->_post('new_password','', lang('password_need'));

        $salt = ConfigHelper::getPasswordSalt();
        $crypt_password = think_ucenter_md5($password,$salt);

        $logic = new UcenterMemberLogic();
        $result = $logic->getInfo(['id'=>$uid]);
        if(!$result['status'] || empty($result['info'])){
            $this->apiReturnErr(lang('invalid_parameter',['param'=>'uid']));
        }

        $userinfo = $result['info'];
        if($userinfo['password'] != $crypt_password){
            $this->apiReturnErr(lang('err_incorrect_password'));
        }


        //2. 调用修改密码
        $action = new UpdateAction();
        $result = $action->updatePwd(['id'=>$uid,'password'=>$crypt_password],$new_password);

        $this->exitWhenError($result,true);
    }

    /**
     * 找回密码-邮箱
     * @author rainbow <email:977746075@qq.com>
     */
    public function updatePwd(){
        $this->checkVersion("100");
        $params  = $this->parsePost('code,email,password','');
        extract($params);
        //? email
        !ValidateHelper::isEmail($email) && $this->apiReturnErr(Linvalid('email'));
        //1. 校验验证码
        $securityCodeLogic = new SecurityCodeLogic();
        $result = $securityCodeLogic->isLegalCode($code,$email,SecurityCode::TYPE_FOR_UPDATE_PSW,$this->client_id);
        $this->exitWhenError($result);

        //2. 调用修改密码
        $action = new UpdateAction();
        $result = $action->updatePwd(['email'=>$email],$password);

        $this->exitWhenError($result,true);
    }

    /**
     * 通过5分钟时效的授权码来修改密码
     * @author hebidu <email:346551990@qq.com>
     */
    public function updatePwdWithAuthCode(){

        $uid = $this->_post('uid','',lang('id_need'));
        $encryptPwd = $this->_post('password','',lang('password_need'));
        $auth_code = $this->_post('auth_code','',lang('invalid_parameter',['param'=>'auth_code']));
        $new_pwd  = $this->_post('new_pwd','',lang('invalid_parameter',['param'=>'new_pwd']));

        $logic  = new UcenterMemberLogic();

        $result = $logic->getInfo(['id'=>$uid,'password'=>$encryptPwd]);

        if(!$result['status']){
            $this->apiReturnErr($result['info']);
        }

        $userinfo = $result['info'];

        if(!is_array($userinfo)){
            $this->apiReturnErr(lang('err_modified'));
        }

        if($auth_code != "itboye" && empty(think_ucenter_decrypt($auth_code,$uid))){
            $this->apiReturnErr(lang('err_auth_code'));
        }

        $action = new UpdateAction();
        $result = $action->updatePwd(['id'=>$uid],$new_pwd);

        $this->exitWhenError($result,true);
    }

    /**
     * 登录接口
     * 101: 增加角色参数
     * 102: 返回角色信息
     * @author hebidu <email:346551990@qq.com>
     */
    public function loginByCode(){

        $this->checkVersion(["102"],"返回角色信息");
        $country = $this->_post('country','');
        $mobile = $this->_post('mobile','',lang('mobile_need'));
        $code = $this->_post('code','');
        $role = $this->_post('role','');

        $device_token = $this->_post('device_token','');
        $device_type  = $this->_post('device_type','');

        $action = new LoginAction();
        $result = $action->loginByCode($this->client_id,$mobile,$code,$country,$device_token,$device_type,$role);

        $this->exitWhenError($result,true);

    }

    /**
     * 登录接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function login(){
        $this->checkVersion("100");
        $params = $this->parsePost('username,password,device_token,device_type|unknown,device_model|unknown','role|'.RoleEnum::ROLE_Driver);
        extract($params);

        //后台登陆
        if($username == 'itboye') $username = 'itboye@itboye.com';

        $action = new LoginAction();
        $result = $action->login($username,$password,'+86',$device_token,$device_type,$role,$device_model,$this->origin_data['client_id']);
        $this->exitWhenError($result,true);
    }

    /**
     * 注册接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function register(){
        $this->checkVersion("100");

        $params = $this->parsePost('mobile,username,code,password','reg_from|0|int');
        extract($params);
        //? 格式检查
        $reg_type = UcenterMember::ACCOUNT_TYPE_EMAIL;
        $email    = $username;
        !ValidateHelper::isEmail($email) && $this->apiReturnErr('暂时只允许邮箱注册');
        !ValidateHelper::isMobile($mobile) && $this->apiReturnErr('手机格式错误');
        !ValidateHelper::isNumber($password,6) && $this->apiReturnErr('密码需为6位数字');

        $entity = [
            'username' =>'user'.time(),
            'password' =>$password,
            'mobile'   =>$mobile,
            'email'    =>$email,
            'country'  =>'+86',
            'reg_from' =>0,
            'reg_type' =>$reg_type,
        ];

        //1. 校验验证码
        $l = new SecurityCodeLogic();
        $r = $l->isLegalCode($code,$email,SecurityCode::TYPE_FOR_REGISTER,$this->client_id);
        $this->exitWhenError($r);

        //2. 调用注册操作
        $action = new RegisterAction();
        $r = $action->register($entity);
        if($r['status'] && intval($r['info']) > 0){
            $this->apiReturnSuc(lang("success"));
        }
        if(is_string($r['info'])){
            $this->apiReturnErr($r['info']);
        }
        $this->apiReturnErr(lang("fail"));
    }

    /**
     * 删除
     * @author hebidu <email:346551990@qq.com>
     */
    public function delete(){
        $this->checkVersion("100");
        $mobile = $this->_post('mobile','',lang('mobile_need'));

        $logic = new DeleteAction();
        $result = $logic->delete($mobile);
        $this->exitWhenError($result,true);
    }

    /**
     * 更新用户的经纬度
     * 100: 更新所在位置
     */
    public function updateLatLng(){
        $id = $this->_post('id','',LangHelper::lackParameter('id'));
        //维度、经度
        $lat = $this->_post('lat','',LangHelper::lackParameter('lat'));
        $lng = $this->_post('lng','',LangHelper::lackParameter('lng'));
        $lat = number_format($lat,4,".","");
        $lng = number_format($lng,4,".","");

        $geoHash = (new GeoHashHelper())->encode($lat,$lng);

        $result = (new MemberLogic())->save(['uid'=>$id],['geohash'=>$geoHash,'lat'=>$lat,'lng'=>$lng]);

        $this->returnResult($result);
    }

    //默认头像 默认年级
    public function getDtree(){
        $this->checkVersion('100');
        $dtree = new DatatreeLogicV2;
        $ret = [];
        //avatar
        $r = (new UserPictureLogic())->queryNoPaging(['type'=>['like','00E001%'],'status'=>1],false,'id,type');
        $this->exitWhenError($r);
        $list = $r['info'];
        $ret['avatar'] = [];
        foreach ($list as $v) {
            $type = $v['type'];
            $typeName = $dtree->getNameByCode($type);
            if(isset($ret['avatar'][$type])){
                $ret['avatar'][$type]['avatar'][] = $v['id'];
            }else{
                $ret['avatar'][$type] = [
                    'code'=>$type,
                    'name'=>$typeName,
                    'avatar' =>[$v['id']],
                ];
            }
        }
        $ret['avatar'] = array_values($ret['avatar']);
        //grade
        $r = $dtree->getCacheList(['parentid'=>getDatatree('grade')]);
        $ret['grade'] = array_values($r);
        $this->apiReturnSuc($ret);
    }

    //根据市区id 获取学校
    public function getSchool(){
        $params = $this->parsePost('area_id|0|int','');
        $area_id = $params['area_id'];

        $r = (new SchoolLogicV2())->queryNoPaging(['area_code'=>$area_id],false,'zone_name as name,id');
        $this->apiReturnSuc($r);
    }
    /**
     * 更换邮箱
     */
    public function changeEmail(){
        $this->checkVersion(100);
        $params = $this->parsePost('email,new_email,code','');
        extract($params);

        $r = (new UpdateAction())->changeEmail($email,$new_email,$code,$this->client_id);
        $this->exitWhenError($r,true);
    }

    /**
     * 更换手机号
     * @Author
     * @DateTime 2017-03-21T14:25:58+0800
     * @return   [type]                   [description]
     */
    public function changeMobile(){
        $this->checkVersion(100);
        $params = $this->parsePost('mobile,mobile_new,s_id,uid','');
        extract($params);

        $r = (new UpdateAction())->changeMobile($uid,$mobile,$mobile_new);
        $this->exitWhenError($r,true);
    }


    public function logout(){

        $uid = $this->_post('uid','',lang('id_need'));
        $auto_login_code = $this->_post('auto_login_code','',lang('auto_login_code_need'));

        $result = (new DefaultUserFacade())->logout($uid,$auto_login_code);
        if(!$result['status']){
            $this->apiReturnErr($result['info']);
        }

        $this->exitWhenError($result,true);
    }
}