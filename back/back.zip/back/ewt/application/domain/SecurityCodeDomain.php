<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-17
 * Time: 11:36
 */

namespace app\domain;

use app\src\base\helper\ResultHelper;
use app\src\base\helper\ValidateHelper;
use app\src\i18n\helper\LangHelper;
use app\src\message\facade\MessageEntity;
use app\src\message\facade\MessageFacade;
use app\src\securitycode\action\SecurityCodeCreateAction;
use app\src\securitycode\action\SecurityCodeVerifyAction;
use app\src\securitycode\enum\CodeTypeEnum;
use app\src\securitycode\model\SecurityCode;
use app\src\user\logic\UcenterMemberLogic;
use app\src\email\action\EmailSendAction;

class SecurityCodeDomain extends BaseDomain
{
    /**
     * 验证码检测
     */
    public function check(){
        $params = $this->parsePost('acceptor,code_type,code','clear|0|int');
        extract($params);
        $clear = $clear ? true:false;
        $action = (new SecurityCodeVerifyAction());
        $r = $action->verify($acceptor,$code_type,$code,$this->client_id,$clear);
        $this->returnResult($r);
    }

    /**
     * 创建
     * @author hebidu <email:346551990@qq.com>
     */
    public function create(){
        $params = $this->parsePost('acceptor,code_type|0|int','code_length|6|int,code_create_way|only_number');
        extract($params);


        $action = (new SecurityCodeCreateAction());
        $r = $action->create($this->client_id,$acceptor,$code_type,$code_create_way,$code_length);
        $this->exitWhenError($r);
        $code = $r['info'];

        if(ValidateHelper::isEmail($acceptor)){
            // 判断邮箱注册
            if(1=== intval($code_type)){
                //1. 检测是否存在邮箱
                $r = (new UcenterMemberLogic)->getInfo(['email'=>$acceptor]);
                if($r['status'] && is_array($r['info']) && !empty($r['info'])){
                    $this->apiReturnErr(lang('tip_email_exist'));
                }
            }
            //发送验证码邮件
            $r = (new EmailSendAction())->sendMail($acceptor,$code,$code_type);
            if(!$r['status']){
                addLog('security_code_create',$r['info'],'','发送邮件失败');
            }
        }elseif(ValidateHelper::isMobile($acceptor)){
            //发送短信 - 见下方 send
            $this->apiReturnErr('手机验证码已转移到send');
        }else{
            //TODO 后台验证码使用了此接口，如果返回错误将无法显示，如何检测session呢
            //$this->apiReturnErr(Linvalid('acceptor'));
        }
        $this->returnResult($r);
    }

    /**
     * 手机校验验证码是否正确,该校验不会让验证码失效
     * @author hebidu <email:346551990@qq.com>
     */
    public function verify(){

        $country = $this->_post('country','', lang('country_tel_number_need'));
        $code = $this->_post('code','', lang('code_need'));
        $mobile = $this->_post('mobile','', lang('mobile_need'));
        $type = $this->_post("code_type","",lang('code_type_need'));

        $this->mobileCheck($country,$mobile,$type);

        $acceptor = $country.$mobile;
        //1. 校验验证码
        $is_clear_code = false;
        $action = new SecurityCodeVerifyAction();
        $result = $action->verify($acceptor,$type,$code,$this->client_id,$is_clear_code);
        $this->returnResult($result);
    }

    /**
     * 手机验证码发送接口
     * @author hebidu <email:346551990@qq.com>
     */
    public function send(){

        $this->checkVersion("101");

        $country = $this->_post("country","",lang('country_tel_number_need'));
        $mobile = $this->_post("mobile","",lang('mobile_need'));
        $type = $this->_post("code_type","",lang('code_type_need'));
        $send_type = $this->_post("send_type","");
        $notes = SecurityCode::getTypeDesc($type);
        if($notes == "未知"){
            $this->apiReturnErr(lang("invalid_parameter",['param'=>'code_type']));
        }
        $this->mobileCheck($country,$mobile,$type);
        $action = new SecurityCodeCreateAction();
        $accepter = $country.$mobile;
        $result = $action->create($this->client_id,$accepter,$type);
        $this->exitWhenError($result);
        $code = $result['info'];

        //根据send_type 来调用返回验证码的渠道
        if(empty($send_type) || $send_type == CodeTypeEnum::Sms){
            //调用短信接口进行 发送
            $msgFacade = new MessageFacade();
            $msg = new MessageEntity();
            $msg->setScene("[".$notes."]");
            $msg->setCode($code);
            $msg->setCountry($country);
            $msg->setMobile($mobile);

            $result = $msgFacade->send($msg);
        }

        if(!empty($send_type) && $send_type == CodeTypeEnum::ALERT){
            $result = ResultHelper::success($code);
        }

        if($result['status']){
            $this->apiReturnSuc($result['info']);
        }else{
            $this->apiReturnErr(lang('fail').'=>'.$result['info']);
        }

    }

    /**
     * 检测手机号和用途的合法性
     * @param $country
     * @param $mobile
     * @param $type
     */
    private function mobileCheck($country,$mobile,$type){
        $map = array(
            'mobile' => $mobile,
            'country_no'=>$country
        );

        $logic = new UcenterMemberLogic();

        $result = $logic->getInfo($map);

        if($type == SecurityCode::TYPE_FOR_REGISTER){
            if ($result['info'] != null) {
                $this->apiReturnErr(lang('tip_mobile_registered'));
            }
        }elseif($type == SecurityCode::TYPE_FOR_UPDATE_PSW ){
            if ($result['info'] == null) {
                $this->apiReturnErr(lang('tip_mobile_unregistered'));
            }
        }
    }

}