<?php
/**
 * Copyright (c) 2017.  hangzhou BOYE .Co.Ltd. All rights reserved
 */

/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-12-13
 * Time: 17:08
 */

return array(
    "tip_success" => "操作成功",
    "err_re_login_"=>"登录会话已超时，请重新登录",
    "err_login_"=>"您的帐号于{:time}在未知设备上登录了，如果这不是你的操作，你的密码已经泄漏。",
    "err_login_android"=>"您的帐号于{:time}在一台android手机上登录了，如果这不是你的操作，你的密码已经泄漏。",
    "err_login_ios"=>"您的帐号于{:time}在一台iphone手机设备上登录了，如果这不是你的操作，你的密码已经泄漏。",
    "err_login_pc"=>"您的帐号于{:time}在一台电脑上登录了，如果这不是你的操作，你的密码已经泄漏。",
    "err_login_weixin"=>"您的帐号于{:time}通过微信登录了，如果这不是你的操作，你的密码已经泄漏。",
    "err_login_web"=>"您的帐号于{:time}在一台手机浏览器上登录了，如果这不是你的操作，你的密码已经泄漏。",

);
