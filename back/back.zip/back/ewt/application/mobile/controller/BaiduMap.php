<?php
/**
 * Copyright (c) 2017.  hangzhou BOYE .Co.Ltd. All rights reserved
 */

/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2017-01-18
 * Time: 16:07
 */

namespace app\mobile\controller;


class BaiduMap extends MobileController
{
    public function position(){

    }
}