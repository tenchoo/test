<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-11-17
 * Time: 11:00
 */

namespace app\src\alipay\action;


use app\src\alipay\po\AlipayNotifyPo;
use app\src\base\action\BaseAction;
use app\src\hook\PaySuccessHook;
use app\src\order\enum\PayCurrency;
use app\src\alipay\logic\AlipayNotifyLogic;
use app\src\order\enum\PayType;

class AlipayNotifyAction extends BaseAction
{
    private $alipay_config;
    private $alipayNotifyPo;

    public function __construct($alipayNotifyPo)
    {
        //old sdk
        // vendor("AlipayApp.lib.alipay_notify");
        $this->alipayNotifyPo = $alipayNotifyPo;
        vendor("AlipayApp.aop20170607.AopClient");

        $this->alipay_config = $this->getAlipayConfig();
    }

    public function notify($post,$is_debug=false){
        //old version
        // $alipayNotify = new \AlipayNotify($this->alipay_config);

        if($is_debug){ //测试环境不验证
            $verify_result = true;
        }else{
            //old version
            // $verify_result = $alipayNotify->verifyNotify();
            $aop = new \AopClient;
            // $aop->alipayrsaPublicKey = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsGlxI+U0mSFrr/82QFNFc7SUfm7VhPFwyBCO6dlDyJWV7MpfUYqQ6bA168yeJuBumihBMFc30evIorNVICESHHo+6/IgSbKS4xhwPBRXWUTWYyIN25afZH878ZjrJDTybK4OIdhi8ueEvxGJRQGHzjR6j1Y8xfzElfj8SGQ/OE2LPa7kmXMx+4IHxicAht0fQx6Dt5e4Wm8p6zd/cZNw5Pu4QHWOmkquLQHZDgzHCvmE9zfXMG6p9aJhqnqrCP+VoPMCqO1pZ2LjTxY8b3F7BEp5Tu+zgAb4FcK1Y7UP/Lzr2jQAjG6HBIpnHzxMDgthIxLV0Qesw2OhmAFUbZycywIDAQAB';
            // $verify_result = $aop->rsaCheckV1($post, null, $post['sign_type']); //注意秘钥格式
            $verify_result = $aop->rsaCheckV1($post, $this->alipay_config['ali_public_key_path'], $post['sign_type']); //注意秘钥格式
        }
        addLog("ALIPAY_NOTIFY_ACTION","签名验证结果:".($verify_result ? '1':'0'),'',"trade_status");
        if($verify_result) {
            //验证成功
            $this->log();
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            //商户订单号
            $out_trade_no =  $this->alipayNotifyPo->getOutTradeNo();

            //支付宝交易号
            $trade_no =  $this->alipayNotifyPo->getTradeNo();

            //交易状态
            $trade_status =  $this->alipayNotifyPo->getTradeStatus();

            //支付金额
            $total_fee =  $this->alipayNotifyPo->getTotalAmount();

            //seller_id
            $seller_id =  $this->alipayNotifyPo->getSellerId();

            addLog("ALIPAY_NOTIFY_ACTION","trade_status:状态判定",$trade_status,"trade_status");

            if($trade_status == 'TRADE_FINISHED') {
                //判断该笔订单是否在商户网站中已经做过处理
                //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
                //如果有做过处理，不执行商户的业务程序

                //注意：
                //退款日期超过可退款期限后（如三个月可退款），支付宝系统发送该交易状态通知
                //请务必判断请求时的total_fee、seller_id与通知时获取的total_fee、seller_id为一致的

                //调试用，写文本函数记录程序运行情况是否正常
                //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
                $this->payFinished($seller_id,$total_fee,$out_trade_no,$trade_no);
            }
            else if ($trade_status == 'TRADE_SUCCESS') {

                //判断该笔订单是否在商户网站中已经做过处理
                //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
                //如果有做过处理，不执行商户的业务程序

                //注意：
                //付款完成后，支付宝系统发送该交易状态通知
                //请务必判断请求时的total_fee、seller_id与通知时获取的total_fee、seller_id为一致的

                //调试用，写文本函数记录程序运行情况是否正常
                //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
                $result = $this->paySuccess($seller_id,$total_fee,$out_trade_no,$trade_no);

                if($result['status']){

                    $r = $this->success('success'); //请不要修改或删除
                    addLog("ALIPAY_NOTIFY_ACTION","订单处理:",$r,'系统交易',"支付宝异步通知处理成功");
                    return $r;
                } else{

                    if($is_debug){
                        $str = "信息:".$result['info'].',交易编号:'.$this->alipayNotifyPo->getOutTradeNo();
                        return $this->error($str);
                    }

                    addLog("ALIPAY_NOTIFY_ACTION","错误信息:".$result['info'],'系统交易编号:'.$this->alipayNotifyPo->getOutTradeNo(),"支付宝异步通知处理异常");
                }
            }


        }else{
            addLog("ALIPAY_NOTIFY_ACTION","错误信息: 验证失败",'系统交易编号:',"支付宝异步通知处理异常");
        }
        return $this->error('fail');
    }


    /**
     * 支付完成
     * @param $seller_id
     * @param $total_fee
     * @param $out_trade_no
     * @param $trade_no
     */
    private function payFinished($seller_id,$total_fee,$out_trade_no,$trade_no){
        (new PaySuccessHook())->finished($seller_id,$total_fee * 100,$out_trade_no,$trade_no);
    }

    /**
     * 支付成功
     * @param $seller_id
     * @param $total_fee
     * @param $out_trade_no
     * @return \app\src\base\logic\status|array|bool|void
     */
    private function paySuccess($seller_id,$total_fee,$out_trade_no,$trade_no){

        //1. 对支付宝默认其货币为: 人民币：元，所以 * 100 转换为分
        $result =  (new PaySuccessHook())->success($seller_id,$total_fee * 100,$out_trade_no,PayCurrency::RMB,$trade_no,PayType::ALIPAY);

        return $result;
    }

    /**
     * 记录日志
     * @author hebidu <email:346551990@qq.com>
     */
    private function log(){
        $entity = array(
            'payment_type' => "",
            'subject' => $this->alipayNotifyPo->getSubject(),
            'trade_no' => $this->alipayNotifyPo->getTradeNo(),
            'buyer_email' => "",
            'gmt_create' => $this->alipayNotifyPo->getSellerEmail(),
            'notify_type' => $this->alipayNotifyPo->getNotifyType(),
            'quantity' => 0,
            'out_trade_no' => $this->alipayNotifyPo->getOutTradeNo(),
            'seller_id' => $this->alipayNotifyPo->getSellerId(),
            'notify_time' => $this->alipayNotifyPo->getNotifyTime(),
            'body' => $this->alipayNotifyPo->getBody(),
            'trade_status' => $this->alipayNotifyPo->getTradeStatus(),
            'is_total_fee_adjust' => "",
            'total_fee' => $this->alipayNotifyPo->getTotalAmount(),
            'seller_email' => $this->alipayNotifyPo->getSellerEmail(),
            'use_coupon' => "",
            'buyer_id' => $this->alipayNotifyPo->getBuyerId(),
            'notify_id' => $this->alipayNotifyPo->getNotifyId(),
            'price' => $this->alipayNotifyPo->getTotalAmount(),
            'sign_type' => $this->alipayNotifyPo->getSignType(),
            'sign' => $this->alipayNotifyPo->getSign(),
            'gmt_payment' => $this->alipayNotifyPo->getGmtPayment()
        );

        $result = (new AlipayNotifyLogic())->add($entity);

        if(!$result['status']){
            LogRecord($result['info'],__FILE__.__LINE__);
        }

    }


    private function getAlipayConfig(){

        //↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
        //合作身份者id，以2088开头的16位纯数字
        // $alipay_config['partner']		= '2088721193827275';//正式

        //商户的私钥（后缀是.pen）文件相对路径
        // $alipay_config['private_key_path']	= APP_PATH.'src/alipay/key/rsa2_private_key.pem';

        //支付宝公钥（后缀是.pen）文件相对路径
        $alipay_config['ali_public_key_path']= APP_PATH.'src/alipay/key/alipay_public_key.pem';

        //↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

        //签名方式 不需修改 验证rsa 发起rsa2
        // $alipay_config['sign_type']    = strtoupper('RSA');

        //字符编码格式 目前支持 gbk 或 utf-8
        // $alipay_config['input_charset']= strtolower('utf-8');

        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        // $alipay_config['cacert']    = getcwd().'\\cacert.pem';

        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        // $alipay_config['transport']    = 'http';

        return  $alipay_config;
    }
}