<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-11-10
 * Time: 22:15
 */

namespace app\src\alipay\model;


use think\Model;

class AlipayNotify extends Model
{

}