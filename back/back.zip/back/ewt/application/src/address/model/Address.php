<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-18
 * Time: 18:08
 */

namespace app\src\address\model;

use think\Model;

class Address extends Model
{
    
}