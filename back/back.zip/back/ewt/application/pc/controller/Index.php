<?php
/**
 * Author      : rainbow <hzboye010@163>
 * DateTime    : 2017-07-18 10:18:00
 * Description : [Description]
 */

namespace app\pc\controller;

/**
 * Class Index
 * pc首页
 * @package app\web\controller
 */
class Index extends Base{
  public function _initialize() {
    parent::_initialize();
  }

  public function index(){
    $this->assign('title', '易▪微听 英语学习好帮手');
    return $this->fetch();
  }
}